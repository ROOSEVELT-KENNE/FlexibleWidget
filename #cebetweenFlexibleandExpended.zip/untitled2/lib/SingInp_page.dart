
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class SingInPage extends StatefulWidget {
  const SingInPage({Key? key}) : super(key: key);

  @override
  State<SingInPage> createState() => _SingInPageState();
}

class _SingInPageState extends State<SingInPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: const Text('Inscription'),
        ),
        body: Container(
          decoration: const BoxDecoration(
              gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: <Color>[
                Colors.grey,
                Colors.lightBlue,
                Colors.blue,
              ])),
          child: Center(
              child: ListView(
            children: [
              Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  TopSection,
                  const BackButtom(),
                ],
              )
            ],
          )),
        ));
  }
}
Widget TopSection = Container(
  padding: const EdgeInsets.all(30),
  child: Row(
    children: [
      BackButton(color: Colors.white,),
      Text('avez vous un compte ?',style: GoogleFonts.comfortaa(fontSize: 20,color: Colors.white,fontWeight: FontWeight.bold)),

    ],
  ),

);



class BackButtom extends StatelessWidget {
  const BackButtom({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        inputSections,
        SingUpWidget(),
      ],
    );
  }
}
Widget inputSections = Container(
  margin: const EdgeInsets.all(30),
  child: Column(
    children: [
      Container(
        height: 60,
        decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(30),
            color: Colors.white.withOpacity(0.1),
            border: Border.all(width: 1,color: Colors.white30)
        ),
        child:Row(
          children: [
            Container(
              height: 60,
              width: 60,
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(30),
                  color: Colors.white
              ),
              child: const Icon(Icons.people,size: 30,color: Colors.blue,),
            ),
            Container(
                height: 60,
                width: 230,
                child: Center(child: TextField(
                  textAlign: TextAlign.center,
                  obscureText: false,
                  style: GoogleFonts.comfortaa(fontSize: 20,color: Colors.white,fontWeight: FontWeight.bold),
                  decoration: InputDecoration(
                      hintText: 'Pseudo',hintStyle: GoogleFonts.comfortaa(fontSize: 20,color: Colors.white,),
                      border: InputBorder.none
                  ),

                ))
            )
          ],
        ) ,
      ),
      const SizedBox(height: 30,),
      Container(
        height: 60,
        decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(30),
            color: Colors.white.withOpacity(0.1),
            border: Border.all(width: 1,color: Colors.white30)
        ),
        child:Row(
          children: [
            Container(
              height: 60,
              width: 60,
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(30),
                  color: Colors.white
              ),
              child: const Icon(Icons.email_outlined,size: 30,color: Colors.blue,),
            ),
            Container(
                height: 60,
                width: 230,
                child: Center(child: TextField(
                  textAlign: TextAlign.center,
                  obscureText: false,
                  style: GoogleFonts.comfortaa(fontSize: 20,color: Colors.white,fontWeight: FontWeight.bold),
                  decoration: InputDecoration(
                      hintText: 'Adresse Mail',hintStyle: GoogleFonts.comfortaa(fontSize: 20,color: Colors.white,),
                      border: InputBorder.none
                  ),

                ))
            )
          ],
        ) ,
      ),
      const SizedBox(height:30 ,),
      Container(
        height: 60,
        decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(30),
            color: Colors.white.withOpacity(0.1),
            border: Border.all(width: 1,color: Colors.white30)
        ),
        child:Row(
          children: [
            Container(
              height: 60,
              width: 60,
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(30),
                  color: Colors.white
              ),
              child: const Icon(Icons.lock_outline,size: 30,color: Colors.blue,),
            ),
            Container(
                height: 60,
                width: 230,
                child: Center(child: TextField(
                  textAlign: TextAlign.center,
                  obscureText: true,
                  style: GoogleFonts.comfortaa(fontSize: 20,color: Colors.white,fontWeight: FontWeight.bold),
                  decoration: InputDecoration(
                      hintText: 'Mot de pass',hintStyle: GoogleFonts.comfortaa(fontSize: 20,color: Colors.white,),
                      border: InputBorder.none
                  ),

                ))
            )
          ],
        ) ,
      ),
      const SizedBox(height: 30,),
      Container(
        height: 60,
        decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(30),
            color: Colors.white.withOpacity(0.1),
            border: Border.all(width: 1,color: Colors.white30)
        ),
        child:Row(
          children: [
            Container(
              height: 60,
              width: 60,
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(30),
                  color: Colors.white
              ),
              child: const Icon(Icons.date_range_outlined,size: 30,color: Colors.blue,),
            ),
            Container(
                height: 60,
                width: 230,
                child: Center(child: TextField(
                  textAlign: TextAlign.center,
                  obscureText: false,
                  style: GoogleFonts.comfortaa(fontSize: 20,color: Colors.white,fontWeight: FontWeight.bold),
                  decoration: InputDecoration(
                      hintText: 'Date de Naissance',hintStyle: GoogleFonts.comfortaa(fontSize: 20,color: Colors.white,),
                      border: InputBorder.none
                  ),

                ))
            )
          ],
        ) ,
      )
    ],
  ),
);
class SingUpWidget extends StatelessWidget {
  const SingUpWidget({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return RaisedButton(
        padding: const EdgeInsets.fromLTRB(100, 15,100, 15),
        color: Colors.white,
        textColor: Colors.blue,
        shape:RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
        onPressed: (){}, child: Text('Inscription'.toUpperCase(), style: GoogleFonts.comfortaa(fontSize: 20,color: Colors.blue,fontWeight: FontWeight.bold),));
  }
}

