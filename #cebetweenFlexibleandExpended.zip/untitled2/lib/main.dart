import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:video_player/video_player.dart';

void main() {
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'Flutter Demo',
    theme: ThemeData(
      primarySwatch: Colors.blue,
    ),
    home: PaddingWork(),
  ));
}

class PaddingWork extends StatefulWidget {
  const PaddingWork({Key? key}) : super(key: key);

  @override
  State<PaddingWork> createState() => _PaddingWorkState();
}

class _PaddingWorkState extends State<PaddingWork> {
 bool topExpended =false;
 bool buttomExpended =false;
 void topexpe(){
   setState((){
     topExpended=!topExpended;
   });
 }
 void bopexpe(){
   setState((){
     buttomExpended=!buttomExpended;
   });
 }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: const Text('EXpended'),
          actions: [
            Row(children: [
              ElevatedButton.icon(
            label:topExpended?const Text("tigh"):const Text('loose'),
                  onPressed: (){topexpe();}, icon:topExpended?Icon(Icons.expand_more):Icon(Icons.expand_less)),
              ElevatedButton.icon(
              icon:buttomExpended?Icon(Icons.expand_more):Icon(Icons.expand_less),
                label:buttomExpended?Text('expended'):Text('no expended'),
               onPressed:(){bopexpe();}),

            ],)

          ],
        ),
        body: SafeArea(
            child: Center(
              child: Column(
                children: [
                  Flexible(child: topContainer,fit: topExpended? FlexFit.tight:FlexFit.loose),
                  buttomExpended? Expanded(child: bottomContainer,):bottomContainer,
                ],
              ),
            )));
  }
}
Widget topContainer=Container(
  constraints: const BoxConstraints(minWidth: 100,minHeight: 100,maxHeight: 200,maxWidth: 200),
  padding: const EdgeInsets.fromLTRB(20, 13, 20, 10),
  width: 200,
  height:60,
  decoration:BoxDecoration(
      color: Colors.yellow,
      border: Border.all(width: 1, color: Colors.black87)),

  child: Text('TopContainer',style: GoogleFonts.aclonica(color: Colors.black87,fontSize: 20),),

);
Widget bottomContainer =Container(
  constraints: const BoxConstraints(minWidth: 100,minHeight: 100,maxHeight: 200,maxWidth: 200),
  padding: const EdgeInsets.fromLTRB(100, 13, 30, 10),
  width: 400,
  height: 60,
  decoration: BoxDecoration(
      color: Colors.red,
      border: Border.all(width: 1, color: Colors.black87)),
  child: Text('BottomContainer',style: GoogleFonts.aclonica(color: Colors.black87,fontSize: 20),),
);
